import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:milk_matters_donor_app/customWidgets/cards/FaqCard.dart';
import 'package:milk_matters_donor_app/customWidgets/NavDrawer.dart';

/// The page containing several Frequently Asked Questions, and their
/// associated answers. Implemented as a StatefulWidget.
class FrequentlyAskedQuestions extends StatelessWidget {

  /// Contains question 1.
  String question1 = "Will I have enough milk to donate?";
  /// Contains answer 1.
  String answer1 = "- By expressing extra milk for another baby, you will not "
      "deprive your baby in any way – in fact, expressing will increase your "
      "milk supply.\n\n- Just 50ml can feed a baby of <1kg for 24 hours.\n\n"
      "- Please do not put your own baby onto formula in order to donate milk "
      "– your baby comes first and needs your milk!";

  /// Contains question 2.
  String question2 = "How do I become a donor?";
  /// Contains answer 2.
  String answer2 = "- Contact us and we will ask you to fill in a Screening "
      "Form.\n\n- We also require you to have an HIV and Hepatitis B test at "
      "no cost to you.\n\n- Long-term donors will be requested to repeat the "
      "HIV test.";

  /// Contains question 3.
  String question3 = "Will my donated milk be sold?";
  /// Contains answer 3.
  String answer3 = "The milk itself is not sold. A processing fee is charged to"
      " partially cover the cost of collecting, screening, pasteurising and "
      "dispensing the donor milk.";

  /// Contains question 4.
  String question4 = "How do I express milk?";
  /// Contains answer 4.
  String answer4 = "Always wash your hands well before expressing.\n\n-Hand "
      "expressing is acceptable.\n\n-If using a pump, dis-assemble all the "
      "pump parts, wash and sterilise before use.\n\n-Second-hand or hired "
      "breastpumps are not recommended with the exception of the Medela "
      "Lactina multi-user pumps if each user has her own attachments unused "
      "by others.";

  /// Contains question 5.
  String question5 = "How do I clean and sterilise my pump?";
  /// Contains answer 5.
  String answer5 = "Dis-assemble pump and wash all pump parts separately in hot"
      " soapy water.\n\n-Rinse and sterilise as stipulated by the pump "
      "manufacturer.\n\n-Avoid sterilising solutions where possible. Boiling or"
      " steaming pump parts is preferable and more effective.";

  /// Contains question 6.
  String question6 = "What containers can I use?";
  /// Contains answer 6.
  String answer6 = "- Sterile glass or hard plastic (BPA free) jars with screw "
      "top lids are ideal and available from Milk Matters.\n\n- Please do not "
      "use ice cube trays or plastic bags.\n\n-We are unable to guarantee "
      "that your containers will be returned, but will do our best to return "
      "them to you.\n\n-Containers need not be full but a new container must be"
      " used each time you express.\n\n-Please leave plenty of head space in "
      "the container for expansion when freezing.";

  /// Contains question 7.
  String question7 = "How do I sterilise the containers?";
  /// Contains answer 7.
  String answer7 = "-Containers that you receive from our depots are sterile."
      "\n\n-Should you need to sterilise your own containers:\n\t+Wash the jars"
      " & lids in hot soapy water & rinse well\n\t+Submerge in a pot of water "
      "and boil for 10 minutes\n\t+Sterilising solutions are not recommended."
      "\n\t+Do not touch the inside of the containers and lids.";

  /// Contains question 8.
  String question8 = "How do I store breastmilk?";
  /// Contains answer 8.
  String answer8 = "-Please label the jars with your name / donor number and "
      "the date. Masking tape is ideal for labelling.\n\n-When freezing your "
      "milk, place jar of expressed milk in the small paper bag it was supplied"
      " in.\n\n-Cool the milk in the fridge and freeze within 24 hours of "
      "expressing. Please freeze the jar standing upright where possible."
      "\n\n-Milk needs to be kept separate from other items in the freezer to "
      "prevent contamination.";

  /// Contains question 9.
  String question9 = "How do I get my milk to the milk bank?";
  /// Contains answer 9.
  String answer9 = "-Transport your donor milk to the nearest depot, in a "
      "coolbox with ice bricks on top of the milk (cold air sinks). Milk must "
      "always remain frozen.\n\n-Please contact Milk Matters for details of the"
      " depots in your area, or to discuss alternative arrangements.";

  @override
  /// Builds the page, using the provided BuildContext
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: Colors.blue[50],
            appBar: AppBar(
              title: Text(
                'Frequently Asked Questions',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.grey[700],
                ),
              ),
              centerTitle: true,
              elevation: 1.0,
              backgroundColor: Hexcolor('#fddcd8'),
              iconTheme: IconThemeData(
                color: Colors.grey[700],
              ),
            ),
            drawer: NavDrawer('ContactAbout'),
            body: Container(
                child: ListView(
                  physics: BouncingScrollPhysics(),
                  children: <Widget>[
                    FaqCard(question: question1, answer: answer1),
                    FaqCard(question: question2, answer: answer2),
                    FaqCard(question: question3, answer: answer3),
                    FaqCard(question: question4, answer: answer4),
                    FaqCard(question: question5, answer: answer5),
                    FaqCard(question: question6, answer: answer6),
                    FaqCard(question: question7, answer: answer7),
                    FaqCard(question: question8, answer: answer8),
                    FaqCard(question: question9, answer: answer9),

                  ],
                )
            )
        )
    );
  }
}
