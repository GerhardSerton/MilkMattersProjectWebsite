import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:milk_matters_donor_app/Screens/Home.dart';
import 'package:milk_matters_donor_app/helpers/LocationHelper.dart';
import 'package:milk_matters_donor_app/models/Depot.dart';
import 'package:milk_matters_donor_app/models/TrackedDonation.dart';
import 'package:milk_matters_donor_app/screens/BecomeADonor.dart';
import 'package:milk_matters_donor_app/screens/ContactAbout.dart';
import 'package:milk_matters_donor_app/screens/FrequentlyAskedQuestions.dart';
import 'package:milk_matters_donor_app/screens/depotLocator/Depots.dart';
import 'package:milk_matters_donor_app/models/NewsAndEventsItem.dart';
import 'package:milk_matters_donor_app/screens/NewsAndEvents.dart';
import 'package:milk_matters_donor_app/screens/auth/ForgotPassword.dart';
import 'package:milk_matters_donor_app/screens/auth/Login.dart';
import 'package:milk_matters_donor_app/screens/auth/Register.dart';
import 'package:milk_matters_donor_app/screens/depotLocator/DepotLocator.dart';
import 'package:milk_matters_donor_app/screens/depotLocator/SecurityCheckDepots.dart';
import 'package:milk_matters_donor_app/screens/donationTracking/DeclareDonationDropoff.dart';
import 'package:milk_matters_donor_app/screens/donationTracking/DonationGraphs.dart';
import 'package:milk_matters_donor_app/screens/donationTracking/DonationTracker.dart';
import 'package:milk_matters_donor_app/screens/donationTracking/RecordADonation.dart';
import 'package:milk_matters_donor_app/screens/donationTracking/SecurityCheckDeclareDropoff.dart';
import 'package:milk_matters_donor_app/screens/education/EducationArticles.dart';
import 'package:milk_matters_donor_app/screens/education/EducationCategories.dart';
import 'package:milk_matters_donor_app/screens/education/SuggestAnArticle.dart';
import 'package:milk_matters_donor_app/screens/AuthWrapper.dart';
import 'package:milk_matters_donor_app/services/FirebaseAuthenticationService.dart';
import 'package:milk_matters_donor_app/services/FirebaseDatabaseService.dart';
import 'package:milk_matters_donor_app/services/LocalDatabaseService.dart';
import 'package:provider/provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MilkMattersApp());
}

///The widget that contains the application
class MilkMattersApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return MultiProvider(
      /// The providers below provide data to several screens.
      /// Change notifier providers are used to pass future data to screens on a larger scale: eg, a class which provides multiple futures (FirebaseDatabaseService)
      /// Future providers provide futures of a specific type directly, for example, the list of depots obtained from FirebaseDatabaseService().getDepots()
      /// Stream providers act as normal providers, but provider a stream of data, for example, streaming the auth status of a user (nouser->user->nouser->..)
      providers: [
        ChangeNotifierProvider<FirebaseDatabaseService>(create: (_) => FirebaseDatabaseService(),),
        ChangeNotifierProvider<FirebaseAuthenticationService>(create: (_) => FirebaseAuthenticationService(),),
        ChangeNotifierProvider<LocalDatabaseService>(create: (_) => LocalDatabaseService(),),
        FutureProvider<List<NewsAndEventsItem>>(create: (_) => FirebaseDatabaseService().getNewsAndEvents(),),
        FutureProvider<List<Depot>>(create: (_) => FirebaseDatabaseService().getDepots(),),
        FutureProvider<bool>(create: (_) => LocationHelper().requestLocationPermissions(),),
        StreamProvider<User>.value(value: FirebaseAuthenticationService().user,),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        builder: BotToastInit(),
        navigatorObservers: [BotToastNavigatorObserver()],
        routes: {
          /// Below are the routes that the app has and which widget will be returned for that route.
          /// a single route can be seen as a screen that can be navigated to

          '/': (context) => Wrapper(),
          '/login': (context) => Login(),
          '/register': (context) => Register(),
          '/forgotPassword': (context) => ForgotPassword(),
          '/home': (context) => Home(),
          '/educationCategories': (context) => EducationCategories(),
          '/newsAndEvents': (context) => NewsAndEvents(),
          '/educationArticles': (context) => EducationArticles(),
          '/suggestAnArticle': (context) => SuggestAnArticle(),
          '/depotLocator': (context) => DepotLocator(),
          '/depots': (context) => Depots(),
          '/securityCheckDepots': (context) => SecurityCheckDepots(),
          '/donationTracker': (context) => DonationTracker(),
          '/donationGraphs': (context) => DonationGraphs(),
          '/recordADonation': (context) => RecordADonation(),
          '/declareDonationDropoff': (context) => DeclareDonationDropoff(),
          '/securityCheckDeclareDropoff': (context) => SecurityCheckDeclareDropoff(),
          '/contactMilkMatters': (context) => ContactAbout(),
          '/frequentlyAskedQuestions': (context) => FrequentlyAskedQuestions(),
          '/becomeADonor': (context) => BecomeADonor(),
        },
      ),
    );
  }
}


