package com.milk_matters_interface

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
