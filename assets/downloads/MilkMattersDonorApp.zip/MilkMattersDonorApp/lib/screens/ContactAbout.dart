import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:milk_matters_donor_app/customWidgets/NavDrawer.dart';

/// The stateless widget which displays the contact us screen
///
/// Provides information about Milk Matters, and their contact details
class ContactAbout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          backgroundColor: Colors.blue[50],
          appBar: AppBar(
            title: Text(
              'Contact Milk Matters',
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey[700],
              ),
            ),
            centerTitle: true,
            elevation: 1.0,
            backgroundColor: Hexcolor('#fddcd8'),
            iconTheme: IconThemeData(
              color: Colors.grey[700],
            ),
          ),
          drawer: NavDrawer('ContactAbout'),
          body: Container(
            padding: EdgeInsets.all(10.0),
            child: ListView(
              physics: BouncingScrollPhysics(),
              children: <Widget>[
                Container(
                  padding: EdgeInsets.all(10.0),
                  child: Card(
                    clipBehavior: Clip.antiAlias,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          ListTile(
                            leading: Image.asset('assets/milk_matters_logo_login.png'),
                            title: Text("Our Mission"),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Text(
                              "Milk Matters is a community-based breast milk bank "
                                  "that pasteurises and distributes donations of "
                                  "screened breast milk from healthy donors to "
                                  "premature, ill and vulnerable babies whose own "
                                  "mothers cannot supply the breast milk to meet "
                                  "their baby’s needs. Milk Matters also "
                                  "facilitates the setting up of milk banks in "
                                  "health institutions.",
                              style: TextStyle(color: Colors.black.withOpacity(0.6)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(10.0),
                  child: Card(
                    clipBehavior: Clip.antiAlias,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          ListTile(
                            leading: Image.asset('assets/milk_matters_logo_login.png'),
                            title: Text("Our Values"),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Text(
                              "Milk Matters will work on expanding the delivery of "
                                  "pasteurised donor milk to all babies in need, "
                                  "while educating parents and health workers to "
                                  "facilitate breastfeeding for all babies and "
                                  "provision of the mother’s own milk to "
                                  "vulnerable babies whenever possible. In this "
                                  "way, Milk Matters will contribute to the "
                                  "health and well-being of babies and mothers.",
                              style: TextStyle(color: Colors.black.withOpacity(0.6)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(10.0),
                  child: Card(
                    clipBehavior: Clip.antiAlias,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          ListTile(
                            leading: Image.asset('assets/milk_matters_logo_login.png'),
                            title: Text("Contact Us"),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Text(
                              "Cell: 082 895 8004\nOffice: 021 659 5599\nEmail: info@milkmatters.org",
                              style: TextStyle(color: Colors.black.withOpacity(0.6)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              ],
            )
          )
        )
    );
  }
}
