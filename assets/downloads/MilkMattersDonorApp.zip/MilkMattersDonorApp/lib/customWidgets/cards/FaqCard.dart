import 'package:flutter/material.dart';

/// A custom widget, designed to display a FAQ entry as an expandable card.
class FaqCard extends StatefulWidget {


  /// Contains the FAQ question.
  String question;
  /// Contains the FAQ answer.
  String answer;
  /// Constructor
  FaqCard({this.question, this.answer});

  @override
  /// Creates the state containing the functionality for the widget.
  _FaqCard createState() => _FaqCard(question: this.question, answer: this.answer);

}

/// The state created by the widget.
class _FaqCard extends State<FaqCard>
{
  /// Constructor
  _FaqCard({this.question, this.answer});

  /// Contains the FAQ question.
  String question;
  /// Contains the FAQ answer.
  String answer;
  //Icon icon = Icon(Icons.check_box_outline_blank);
  @override
  /// Builds the widget, using the provided BuildContext.
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(0.5),
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: ExpansionTile(
          title: Text(question),
          children: <Widget>[Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(answer, style: TextStyle(color: Colors.black.withOpacity(0.6))),
          ),
          ],
        ),
      )

    );
  }
}