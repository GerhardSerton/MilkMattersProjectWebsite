# milk_matters_interface
These instructions will help to get the basic development environment up and running.
 
Step 1: Download and install Flutter (instructions can be found here: https://flutter.dev/docs/get-started/install). Please ensure that you download the latest STABLE version.
 
Step 2: Download and install your preffered IDE (https://flutter.dev/docs/get-started/editor)
 
Step 3: Follow the instructions in the following link to set-up Flutter Web - https://flutter.dev/docs/get-started/web
When building this mobile app, please use the beta Flutter channel by running "flutter channel beta" and then "flutter upgrade".

Step 4: Import the project into your IDE.
 
Step 5: Build the project
 
If you would like to demo the web application, you can create a Chrome Browser simulated device.
