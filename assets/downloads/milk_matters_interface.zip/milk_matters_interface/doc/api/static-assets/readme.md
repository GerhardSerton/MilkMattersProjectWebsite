# highlight.js

Generated from https://highlightjs.org/download/ on 2019-05-16

Included languages:

* bash
* css
* dart
* html, xml
* java
* javascript
* json
* kotlin
* markdown
* objective-c
* shell
* swift
* yaml
