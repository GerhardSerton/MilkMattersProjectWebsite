import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:fluttericon/font_awesome5_icons.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:intl/intl.dart';
import 'package:milk_matters_donor_app/models/TrackedDonation.dart';
import 'package:milk_matters_donor_app/services/LocalDatabaseService.dart';
import 'package:provider/provider.dart';


/// A stateless widget allowing donors to record a donation
class RecordADonation extends StatelessWidget {

  /// The key used to store the form state
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();
  /// Initialise controllers used to retrieve form input data
  final donationAmountController = TextEditingController();
  final donationDateController = TextEditingController();

  @override
  Widget build(BuildContext context) {

    /// Setup the provider to access the local SQL database
    final localDBProvider = Provider.of<LocalDatabaseService>(context);

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.blue[50],
        appBar: AppBar(
          title: Text(
          'Record A Donation',
          style: TextStyle(
            fontSize: 18,
            color: Colors.grey[700],
            ),
          ),
          centerTitle: true,
          elevation: 1.0,
          backgroundColor: Hexcolor('#fddcd8'),
          iconTheme: IconThemeData(
          color: Colors.grey[700],
          ),
        ),
        body: Container(
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.all(50),
                child: FormBuilder(
                  key: _fbKey,
                  child: Column(
                    children: [
                      FormBuilderTextField(
                        attribute: 'donationAmount',
                        controller: donationAmountController,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: "Donation Amount (ml)",
                          icon: Icon(FontAwesome5.prescription_bottle),
                        ),
                        validators: [
                          FormBuilderValidators.required(
                              errorText: 'Please enter a donation amount.'
                          ),
                          FormBuilderValidators.numeric(
                              errorText: 'Please enter a valid number.'
                          ),
                        ],
                      ),
                      FormBuilderDateTimePicker(
                        attribute: 'donationDate',
                        controller: donationDateController,
                        inputType: InputType.date,
                        format: DateFormat("dd/MM/yyyy"),
                        initialDate: DateTime.now(),
                        initialValue: DateTime.now(),
                        decoration: InputDecoration(
                          labelText: "Donation Date",
                          icon: Icon(FontAwesome5.calendar_day),
                        ),
                        validators: [
                          FormBuilderValidators.required(
                              errorText: 'Please provide a donation date.'
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              RaisedButton.icon(
                label: Text(
                  'Record Donation',
                  style: TextStyle(
                    fontSize: 18.0,
                    color: Colors.grey[200],
                  ),
                ),
                icon: Icon(
                  Icons.playlist_add,
                  color: Colors.grey[200],
                ),
                color: Hexcolor('#dc0963'),
                onPressed: () async {
                  if(_fbKey.currentState.validate()) {
                    BotToast.showLoading();
                    TrackedDonation donation = TrackedDonation.withoutId(
                        amount: int.parse(donationAmountController.text),
                        dateRecorded: donationDateController.text, donationProcessed: false);
                    await localDBProvider.insert(donation);
                    BotToast.closeAllLoading();
                    Navigator.pop(context);
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
