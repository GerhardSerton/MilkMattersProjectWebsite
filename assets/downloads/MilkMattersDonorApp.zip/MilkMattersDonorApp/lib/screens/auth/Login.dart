import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:fluttericon/elusive_icons.dart';
import 'package:fluttericon/iconic_icons.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:milk_matters_donor_app/helpers/AuthResultStatus.dart';
import 'package:milk_matters_donor_app/helpers/AuthExceptionHandler.dart';
import 'package:milk_matters_donor_app/models/DonorUser.dart';
import 'package:milk_matters_donor_app/services/FirebaseAuthenticationService.dart';
import 'package:milk_matters_donor_app/services/FirebaseDatabaseService.dart';
import 'package:provider/provider.dart';

/// This stateful widget displays the Login screen
///
/// It provides users with a way to login to the application,
/// by entering an email and password.
/// It contains buttons to navigate to the register and forgot password screens
class Login extends StatefulWidget {
  @override
  /// Creates the state containing the functionality and widget tree.
  _LoginState createState() => _LoginState();
}

/// The state created by the widget.
class _LoginState extends State<Login> {

  /// Key used to access the state of the form
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();

  /// Controllers to access the form's input fields
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  bool loaded = false;
  Image mmLogoImg;

  @override
  void didChangeDependencies() {
    precacheImage(mmLogoImg.image, context).then((value){
/*      setState(() {
        loaded = true;
      });*/
    });
    super.didChangeDependencies();
  }

  @override
  void initState() {
    super.initState();
    mmLogoImg = Image.asset('assets/milk_matters_logo_login.png');
  }

  @override
  /// Builds this screens widget tree
  Widget build(BuildContext context) {

    /// Provider used to access the firebase database
    var _authProvider = Provider.of<FirebaseAuthenticationService>(context);

    return SafeArea(
      child: Scaffold(
        backgroundColor: Hexcolor('#fddcd8'),
        body: loaded == false ? Container(child: Center(child: CupertinoActivityIndicator(radius: 30.0))) :
        SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 8.0, 0, 0.0),
                child: mmLogoImg,
              ),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: Text(
                  'Welcome to the Milk Matters App!\nLogin below, or create an account to get started.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 2.0,
                    color: Colors.grey[700],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(20,0,20,5),
                child: Container(
                  decoration: BoxDecoration(
                    //color: Hexcolor('#7588fd'),//blue
                    color: Hexcolor('#f2e6bb'), //Light yellow
                    //color: Hexcolor('#f5eccc'), //Lighter yellow
                    boxShadow: <BoxShadow>[
                      BoxShadow(
                        color: Colors.grey[500],
                        offset: Offset(0.3, 0.3),
                        blurRadius: 3.0,
                      ),
                    ],
                    borderRadius: BorderRadius.all(Radius.circular(25.0)),
                  ),
                  child: Column(
                    children: [
                      FormBuilder(
                        key: _fbKey,
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(30.0, 5.0, 30.0, 5.0),
                          child: Column(
                            children: <Widget>[
                              FormBuilderTextField(
                                controller: emailController,
                                attribute: "email",
                                decoration: InputDecoration(
                                  labelText: "Email",
                                  icon: Icon(Icons.email),
                                  //focusedBorder:
                                ),
                                validators: [
                                  FormBuilderValidators.required(
                                      errorText: 'Please enter an email address.'
                                  ),
                                  FormBuilderValidators.email(
                                      errorText: 'Please enter a valid email address.'
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 5.0,
                              ),
                              FormBuilderTextField(
                                controller: passwordController,
                                attribute: "password",
                                obscureText: true,
                                decoration: InputDecoration(
                                  labelText: "Password",
                                  icon: Icon(Icons.lock),
                                ),
                                validators: [
                                  FormBuilderValidators.required(
                                      errorText: 'Please enter a password.'
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      /// Navigate to the forgot password screen
                      FlatButton(
                        onPressed: () {
                          Navigator.pushNamed(context, '/forgotPassword');
                        },
                        child: Text(
                          'Forgot your password?',
                          style: TextStyle(
                            color: Colors.grey[600],
                          ),
                        ),
                      ),
                      RaisedButton(
                        child: Text(
                          'Login',
                          style: TextStyle(
                            fontSize: 18.0,
                            color: Colors.grey[200],
                          ),
                        ),
                        color: Hexcolor('#dc0963'),
                        /// If the input form is successfully validated,
                        /// then attempt to sign in using the provided credentials.
                        onPressed: () async  {
                          //Login functionality
                          if(_fbKey.currentState.validate()) {
                            BotToast.showLoading();
                            AuthResultStatus result = await _authProvider.signInEmailPassword(
                                emailController.text,
                                passwordController.text);
                            BotToast.closeAllLoading();
                            if(result!=AuthResultStatus.successful){
                              BotToast.showText(
                                text: AuthExceptionHandler.generateExceptionMessage(result),
                              );
                            }
                          }
                        },
                      ),
                      FlatButton(
                        /// Navigate to the registration screen
                        onPressed: () {
                          Navigator.pushNamed(context, '/register');
                        },
                        child: Text(
                          'Create an Account',
                          style: TextStyle(
                            decoration: TextDecoration.underline,
                            fontSize: 16.0,
                            //fontWeight: FontWeight.w400,
                            letterSpacing: 1.0,
                            color: Colors.grey[700],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
