import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:milk_matters_donor_app/models/EducationArticle.dart';
import 'package:milk_matters_donor_app/helpers/Base64Image.dart';
import 'package:share/share.dart';
import 'package:url_launcher/url_launcher.dart';

/// A card which displays the detail of an [eduArticle].
///
/// It displays:
/// The article image (defaults to the MM logo)
/// The article title
/// The date it was added
/// Within an ExpandedTile(
///   Article description
///   Article URL
/// )
/// It also includes a share button to share the content.
class ArticleCard extends StatelessWidget {

  EducationArticle eduArticle;

  ArticleCard({this.eduArticle});
  
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10.0),
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: Column(
          children: [
            ListTile(
              leading: eduArticle.image == 'none' ? Image.asset('assets/milk_matters_logo_login.png') : imageFromBase64String(eduArticle.image),
              title: Text(eduArticle.title),
              subtitle: Text(
                eduArticle.dateAdded,
                style: TextStyle(color: Colors.black.withOpacity(0.6)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: RichText(
                text: TextSpan(
                  text: eduArticle.url,
                  style: TextStyle(color: Colors.blueAccent, decoration: TextDecoration.underline,),
                  recognizer: TapGestureRecognizer()
                    ..onTap = () async {
                      if (await canLaunch('http:' + eduArticle.url)) {
                        await launch(
                          'http:' + eduArticle.url,
                          forceSafariVC: false,
                        );
                      }
                    },
                ),
              ),
            ),
            Theme(
              data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
              child: ExpansionTile(
                  title: Text("Read more:"),
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        eduArticle.description,
                        style: TextStyle(color: Colors.black.withOpacity(0.6)),
                      ),
                    ),
                  ],
                ),
            ),
            ButtonBar(
              alignment: MainAxisAlignment.end,
              children: [
                FlatButton.icon(
                  icon: Icon(Icons.share),
                  onPressed: () {
                    final RenderBox box = context.findRenderObject();
                    Share.share('I found this article on the Milk Matters Mobile App: ' + eduArticle.title + ' ' + eduArticle.url,
                    sharePositionOrigin:
                    box.localToGlobal(Offset.zero) &
                    box.size);
                    },
                  label: const Text('Share'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
