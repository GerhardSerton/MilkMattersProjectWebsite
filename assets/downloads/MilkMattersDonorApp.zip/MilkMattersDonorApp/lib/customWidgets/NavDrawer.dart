import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:milk_matters_donor_app/services/FirebaseAuthenticationService.dart';


/// This is the navigation drawer widget (menu bar)
/// The widget itself contains each menu item as a list tile,
/// of which the ontap() triggers processNavigation().

/// Each navdrawer is constructed using the parent screen's name.

class NavDrawer extends StatelessWidget {

  final FirebaseAuthenticationService _authService = FirebaseAuthenticationService();
  String _screenName;

  NavDrawer(String _screenName){
    this._screenName = _screenName;
  }

  /// This method processes the navigation from a particular screen to another via the navigation drawer.
  /// Essentially performs 2 checks,
  /// 1: If already on the screen that was selected, then ignore.
  /// 2: If on a screen other than home, then push a named replacement, otherwise just push the new screen.
  /// This ensures that we always display the home screen if back is pressed on any other screen.
  void processNavigation(BuildContext context, String route, String navigationPressed) {
    if (navigationPressed == _screenName) {
      return;
    } if(_screenName != 'Home'){
        if(_screenName == 'Education Articles'){
          Navigator.pop(context);
        }
        Navigator.pushReplacementNamed(context, route);
        return;
    } else {
        Navigator.pop(context);
        Navigator.pushNamed(context, route);
      return;
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Drawer(
        child: ListView(
          //padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                  color: Colors.white,
                  image: DecorationImage(
                      fit: BoxFit.contain,
                      image: AssetImage('assets/milk_matters_logo_login.png')
                  )
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'),
              onTap: () => {processNavigation(context, '/home', 'Home')},
            ),
            ListTile(
              leading: Icon(Icons.assessment),
              title: Text('Donation Tracker'),
              onTap: () => {processNavigation(context, '/donationTracker', 'Donation Tracker')},
            ),
            ListTile(
              leading: Icon(Icons.location_on),
              title: Text('Depot Locator'),
              onTap: () => {processNavigation(context, '/securityCheckDepots', 'Depot Locator')},
            ),
            ListTile(
              leading: Icon(Icons.book),
              title: Text('Educational Resources'),
              onTap: () => {processNavigation(context, '/educationCategories', 'Education Categories')},
            ),
            ListTile(
              leading: Icon(Icons.calendar_today),
              title: Text('News and Events'),
              onTap: () => {processNavigation(context, '/newsAndEvents', 'News and Events')},
            ),
            ListTile(
              leading: Icon(Icons.call),
              title: Text('Contact Milk Matters'),
              onTap: () => {processNavigation(context, '/contactMilkMatters', 'Contact Milk Matters')},
            ),
            ListTile(
              leading: Icon(Icons.assignment),
              title: Text('Become a Donor'),
              onTap: () => {processNavigation(context, '/becomeADonor', 'Become A Donor')},
            ),
            ListTile(
              leading: Icon(Icons.help),
              title: Text('Frequently Asked Questions'),
              onTap: () => {processNavigation(context, '/frequentlyAskedQuestions', 'Frequently Asked Questions')},
            ),
            ListTile(
              leading: Icon(Icons.exit_to_app),
              title: Text('Logout'),
              onTap: () async {
                dynamic result = await _authService.signOut();
                Navigator.popUntil(context, ModalRoute.withName('/'));
              },
            ),
          ],
        ),
      ),
    );
  }
}
