
/// This class stores the data associated with an education category
class EducationCategory {

  String name;
  String bgImageUrl;


  EducationCategory({this.name, this.bgImageUrl});

}