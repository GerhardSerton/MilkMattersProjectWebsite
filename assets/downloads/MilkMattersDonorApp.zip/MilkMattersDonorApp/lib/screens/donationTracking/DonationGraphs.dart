import 'package:flutter/material.dart';
import 'package:fluttericon/font_awesome5_icons.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:milk_matters_donor_app/customWidgets/NavDrawer.dart';
import 'package:milk_matters_donor_app/screens/donationTracking/FeedsGraph.dart';
import 'package:milk_matters_donor_app/screens/donationTracking/DonationAmountGraph.dart';

/// The stateful widget which contains the donation graphs
///
/// Displays both graphs to the user and allow them to switch between them using a tab
class DonationGraphs extends StatefulWidget {
  @override
  /// Create the widget's state
  _DonationGraphsState createState() => _DonationGraphsState();
}

/// The widget's state
class _DonationGraphsState extends State<DonationGraphs> {

  /// Store the argument defining which graph tab should be shown
  Map arguementData = {};
  int initialTab;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    /// Retrieve the argument data and set the initialTab value.
    arguementData = arguementData.isNotEmpty ? arguementData : ModalRoute.of(context).settings.arguments;
    initialTab = arguementData['initialTab'];

    return SafeArea(
      child: DefaultTabController(
        initialIndex: initialTab,
        length: 2,
        child: Scaffold(
          backgroundColor: Colors.blue[50],
          appBar: AppBar(
            title: Text(
              'Donation Graphs',
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey[700],
              ),
            ),
            centerTitle: true,
            elevation: 1.0,
            backgroundColor: Hexcolor('#fddcd8'),
            iconTheme: IconThemeData(
              color: Colors.grey[700],
            ),
            bottom: TabBar(
              physics: NeverScrollableScrollPhysics(),
              tabs: [
                Tab(icon: Icon(FontAwesome5.prescription_bottle, color: Colors.grey[700]), child: Text('Donations',style: TextStyle(color: Colors.grey[700]),) ),
                Tab(icon: Icon(FontAwesome5.baby, color: Colors.grey[700],), child: Text('50 ml Feeds',style: TextStyle(color: Colors.grey[700]),)),
              ],
            ),
          ),
          drawer: NavDrawer('Donation Graphs'),
          body: Container(
            child: TabBarView(
              physics: NeverScrollableScrollPhysics(),
              children: [
                DonationAmountGraph(),
                FeedsGraph(),
            ],
          ),
        ),
      ),
    ),
    );
  }
}