import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttericon/font_awesome5_icons.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:milk_matters_donor_app/customWidgets/NavDrawer.dart';
import 'package:milk_matters_donor_app/models/TrackedDonation.dart';
import 'package:milk_matters_donor_app/services/LocalDatabaseService.dart';
import 'package:provider/provider.dart';

/// The stateful widget that displays the Donation Tracker screen.
///
/// This screen allows donors to record donations, view their donation history and graphs,
/// and declare donation drop-offs.
class DonationTracker extends StatefulWidget {
  @override
  /// Create the widget's state
  _DonationTrackerState createState() => _DonationTrackerState();
}

/// The widget's state
class _DonationTrackerState extends State<DonationTracker> {

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    /// Setup the provider used to access the local SQL database
    final localDBProvider = Provider.of<LocalDatabaseService>(context);

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.blue[50],
        appBar: AppBar(
          title: Text(
          'Donation Tracking',
          style: TextStyle(
            fontSize: 18,
            color: Colors.grey[700],
            ),
          ),
          centerTitle: true,
          elevation: 1.0,
          backgroundColor: Hexcolor('#fddcd8'),
            iconTheme: IconThemeData(
            color: Colors.grey[700],
          ),
          ),
        drawer: NavDrawer('Donation Tracker'),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: 100,
              child: Flex(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                direction: Axis.horizontal,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(15, 8, 7.5, 8),
                      child: RaisedButton.icon(
                        color: Hexcolor('#dc0963'),
                        elevation: 2,
                        onPressed: (){
                          Navigator.pushNamed(context, '/donationGraphs', arguments: {'initialTab' : 0});
                        },
                        icon: Icon(FontAwesome5.prescription_bottle, color: Colors.grey[200]),
                        label: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            FutureBuilder(
                              future: localDBProvider.getTotalDonatedAmount(),
                              builder: (context, snapshot) {
                                if (!snapshot.hasData) {
                                  return Text(
                                    '0 ml',
                                    style: TextStyle(
                                      fontSize: 18,
                                      color: Colors.grey[200]
                                    ),
                                  );
                                }
                                else {
                                  return Text(
                                    '${snapshot.data.toString()} ml',
                                    style: TextStyle(
                                      fontSize: 18,
                                      color: Colors.grey[200]
                                    ),
                                  );
                                }
                              }
                            ),
                            Text('Donated', style: TextStyle(color: Colors.grey[200]),),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(7.5, 8, 15, 8),
                      child: RaisedButton.icon(
                        color: Hexcolor('#dc0963'),
                        elevation: 2,
                        onPressed: (){
                          Navigator.pushNamed(context, '/donationGraphs', arguments: {'initialTab' : 1});
                        },
                        icon: Icon(FontAwesome5.baby, color: Colors.grey[200]),
                        label: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            FutureBuilder(
                                future: localDBProvider.getTotalDonatedAmount(),
                                builder: (context, snapshot) {
                                  if (!snapshot.hasData) {
                                    return Text(
                                      '0 ml',
                                      style: TextStyle(
                                          fontSize: 18,
                                          color: Colors.grey[200]
                                      ),
                                    );
                                  }
                                  else {
                                    double feeds = double.parse((snapshot.data/50).toStringAsFixed(2));
                                    return Text(
                                      '$feeds days',
                                      style: TextStyle(
                                          fontSize: 18,
                                          color: Colors.grey[200]
                                      ),
                                    );
                                  }
                                }
                            ),
                            Text('of 50ml Feeds', style: TextStyle(color: Colors.grey[200]),),
                          ],
                        )
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: FutureBuilder(
                future: localDBProvider.getAllTrackedDonationsRecentFirst(),
                builder: (context, snapshot) {
                  if(!snapshot.hasData){
                    return Container(child: Center(child: CupertinoActivityIndicator(radius: 50.0)));
                  }
                  else{
                    return Padding(
                      padding: const EdgeInsets.fromLTRB(15, 8, 15, 8),
                      child: Container(
                        decoration: BoxDecoration(
                            color: Hexcolor('#f5eccc'), //Lighter yellow
                            boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: Colors.grey[500],
                                offset: Offset(0.3, 0.3),
                                blurRadius: 1.5,
                              ),
                            ],
                            borderRadius: BorderRadius.all(Radius.circular(15.0))
                        ),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                'Your Donations',
                                style: TextStyle(
                                  fontSize: 18,
                                  letterSpacing: 1,
                                ),
                              ),
                            ),
                            Expanded(
                              child: ListView.builder(
                                physics: BouncingScrollPhysics(),
                                shrinkWrap: true,
                                itemCount: snapshot.data.length,
                                itemBuilder: (context, index) {
                                  TrackedDonation trackedDonation = snapshot.data[index];
                                  return ListTile(
                                    title: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text('${trackedDonation.amount} ml'),
                                        //Text('${trackedDonation.dateRecorded}'),
                                      ],
                                    ),
                                    subtitle: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text('${trackedDonation.dateRecorded}'),
                                        trackedDonation.donationProcessed ? Text('Drop-off Complete') : Text('Awaiting Drop-off'),
                                      ],
                                    )
                                  );
                                },
                          ),
                            ),],
                          ),
                      ),
                    );
                  }
                },
              )
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: EdgeInsets.fromLTRB(15, 0, 0, 8),
                  child: RaisedButton.icon(
                    onPressed: ()async{
                      List<TrackedDonation> unprocessedDonations = await localDBProvider.getAllNotDroppedOffTrackedDonationsRecentFirst();
                      if(unprocessedDonations.isEmpty){
                        BotToast.showText(text: 'You do not have any tracked donations to drop off');
                      } else {
                        unprocessedDonations.forEach((element) {element.donationProcessed=true;});
                        await Navigator.pushNamed(context, '/securityCheckDeclareDropoff', arguments: {
                          'UnprocessedDonations': unprocessedDonations,
                        });
                        setState(() {

                        });
                      }
                    },
                    color: Hexcolor('#dc0963'),
                    icon: Icon(Icons.announcement, color: Colors.grey[200],),
                    label: Text(
                      'Declare Donation\nDrop-Off',
                      style: TextStyle(
                        color: Colors.grey[200],
                      ),
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.fromLTRB(0, 0, 15, 8),
                  child: RaisedButton.icon(
                    onPressed: () async {
                      Navigator.pushNamed(context, '/recordADonation');
                    },
                    color: Hexcolor('#dc0963'),
                    icon: Icon(Icons.playlist_add, color: Colors.grey[200],),
                    label: Text(
                      'Record a Donation',
                      style: TextStyle(
                        color: Colors.grey[200],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
