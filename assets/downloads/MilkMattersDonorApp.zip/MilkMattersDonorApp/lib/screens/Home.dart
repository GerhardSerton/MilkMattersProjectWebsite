import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttericon/font_awesome5_icons.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:milk_matters_donor_app/customWidgets/NavDrawer.dart';
import 'package:milk_matters_donor_app/customWidgets/cards/NewsAndEventCard.dart';
import 'package:milk_matters_donor_app/helpers/LocationHelper.dart';
import 'package:milk_matters_donor_app/models/DonorUser.dart';
import 'package:milk_matters_donor_app/models/EducationArticle.dart';
import 'package:milk_matters_donor_app/models/NewsAndEventsItem.dart';
import 'package:milk_matters_donor_app/services/FirebaseAuthenticationService.dart';
import 'package:milk_matters_donor_app/services/FirebaseDatabaseService.dart';
import 'package:milk_matters_donor_app/services/LocalDatabaseService.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

/// The stateful widget which displays the home screen
///
/// This contains buttons to access the donation graphs, Milk Matters social media,
/// and displays the news and events feed
class Home extends StatefulWidget {

  @override
  /// Creates the state containing the functionality and widget tree.
  _HomeState createState() => _HomeState();
}
/// The state created by the widget.
class _HomeState extends State<Home> {

  @override
  Widget build(BuildContext context) {

    /// Setup the providers to access the local database and the news and events feed from the database
    var _localDBProvider = Provider.of<LocalDatabaseService>(context);
    var _newsAndEvents = Provider.of<List<NewsAndEventsItem>>(context);


    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.blue[50],
        appBar: AppBar(
          title: Text(
            'Home',
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey[700],
            ),
          ),
          centerTitle: true,
          elevation: 1.0,
          backgroundColor: Hexcolor('#fddcd8'),
          iconTheme: IconThemeData(
            color: Colors.grey[700],
          ),
        ),
        drawer: NavDrawer('Home'),
        body: Column(
          children: [
            Container(
              height: 100,
              child: Flex(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                direction: Axis.horizontal,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(15, 8, 7.5, 8),
                      child: RaisedButton.icon(
                        color: Hexcolor('#dc0963'),
                        elevation: 2,
                        onPressed: (){
                          Navigator.pushNamed(context, '/donationGraphs', arguments: {'initialTab' : 0});
                        },
                        icon: Icon(FontAwesome5.prescription_bottle, color: Colors.grey[200]),
                        label: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            FutureBuilder(
                                future: _localDBProvider.getTotalDonatedAmount(),
                                builder: (context, snapshot) {
                                  if (!snapshot.hasData) {
                                    return Text(
                                      '0 ml',
                                      style: TextStyle(
                                          fontSize: 18,
                                          color: Colors.grey[200]
                                      ),
                                    );
                                  }
                                  else {
                                    return Text(
                                      '${snapshot.data.toString()} ml',
                                      style: TextStyle(
                                          fontSize: 18,
                                          color: Colors.grey[200]
                                      ),
                                    );
                                  }
                                }
                            ),
                            Text('Donated', style: TextStyle(color: Colors.grey[200]),),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(7.5, 8, 15, 8),
                      child: RaisedButton.icon(
                          color: Hexcolor('#dc0963'),
                          elevation: 2,
                          onPressed: (){
                            Navigator.pushNamed(context, '/donationGraphs', arguments: {'initialTab' : 1});
                          },
                          icon: Icon(FontAwesome5.baby, color: Colors.grey[200]),
                          label: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              FutureBuilder(
                                  future: _localDBProvider.getTotalDonatedAmount(),
                                  builder: (context, snapshot) {
                                    if (!snapshot.hasData) {
                                      return Text(
                                        '0 ml',
                                        style: TextStyle(
                                            fontSize: 18,
                                            color: Colors.grey[200]
                                        ),
                                      );
                                    }
                                    else {
                                      double feeds = double.parse((snapshot.data/50).toStringAsFixed(2));
                                      return Text(
                                        '$feeds days',
                                        style: TextStyle(
                                            fontSize: 18,
                                            color: Colors.grey[200]
                                        ),
                                      );
                                    }
                                  }
                              ),
                              Text('of 50ml Feeds', style: TextStyle(color: Colors.grey[200]),),
                            ],
                          )
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Text(
              'Connect with Milk Matters',
              style: TextStyle(
                fontSize: 14,
                //letterSpacing: 1,
                color: Colors.grey[700],
              ),
            ),
            Container(
              height: 80,
              child: Flex(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                direction: Axis.horizontal,
                children: [
                  Expanded(
                    flex: 1,
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: IconButton(
                        iconSize: 50,
                        onPressed: (){
                          _launchSocial('fb://page/205923258216', 'https://www.facebook.com/MilkMatters');
                        },
                        icon: Icon(FontAwesome5.facebook_square, color: Hexcolor('#dc0963')),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: IconButton(
                        iconSize: 50,
                        onPressed: () async {
                          if (await canLaunch('https://www.instagram.com/milkmattersmilkbank/')) {
                            await launch('https://www.instagram.com/milkmattersmilkbank/');
                          } else {
                            return false;
                          }
                        },
                        icon: Icon(FontAwesome5.instagram_square, color: Hexcolor('#dc0963')),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: IconButton(
                        iconSize: 50,
                        onPressed: () async {
                          if (await canLaunch('http:www.milkmatters.org')) {
                            await launch('http:www.milkmatters.org');
                          } else {
                            return false;
                          }
                        },
                        icon: Icon(FontAwesome5.globe, color: Hexcolor('#dc0963')),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'News and Events Feed',
                style: TextStyle(
                  fontSize: 18,
                  letterSpacing: 1,
                ),
              ),
            ),
            Expanded(
              child: _newsAndEvents == null ? Container(child: Center(child: CupertinoActivityIndicator(radius: 30.0))) :
              Container(
                child: ListView.builder(
                  physics: BouncingScrollPhysics(),
                  // Let the ListView know how many items it needs to build.
                  itemCount: _newsAndEvents.length,
                  // Provide a builder function. This is where the magic happens.
                  // Convert each item into a widget based on the type of item it is.
                  itemBuilder: (context, index) {
                    final item = _newsAndEvents[index];
                    return NewsAndEventCard(
                      newsAndEventsItem: item,
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _launchSocial(String url, String fallbackUrl) async {
    // Don't use canLaunch because of fbProtocolUrl (fb://)
    try {
      bool launched =
      await launch(url, forceSafariVC: false, forceWebView: false);
      if (!launched) {
        await launch(fallbackUrl, forceSafariVC: false, forceWebView: false);
      }
    } catch (e) {
      await launch(fallbackUrl, forceSafariVC: false, forceWebView: false);
    }
  }
}
