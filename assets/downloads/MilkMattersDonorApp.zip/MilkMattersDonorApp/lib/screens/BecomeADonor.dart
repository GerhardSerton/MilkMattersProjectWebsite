import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:milk_matters_donor_app/customWidgets/NavDrawer.dart';
import 'package:flutter_email_sender/flutter_email_sender.dart';
import 'package:milk_matters_donor_app/customWidgets/cards/QuestionCard.dart';
import 'package:milk_matters_donor_app/screens/ContactAbout.dart';

/// The page allowing one to begin the application process to become a donor,
/// implemented as a StatefulWidget.
class BecomeADonor extends StatefulWidget {
  @override
  /// Creates the state containing the functionality for the page.
  _BecomeADonor createState() => _BecomeADonor();

}


/// The state created by the page.
class _BecomeADonor extends State<BecomeADonor> {

  /// Displays question 1.
  QuestionCard question1 = QuestionCard(question: "Do you live in the greater Cape Town area or nearby?", number: 1);
  /// Stores answer to question 1.
  bool answer1 = false;
  /// Stores display icon for question 1, depending on the current answer. (Depreciated)
  Icon icon1 = Icon(Icons.check_box_outline_blank);

  /// Displays question 2.
  QuestionCard question2 = QuestionCard(question: "For the safety of the recipient babies, all potential donor mothers need to be screened via a simple but thorough screening process. As part of the screening, are you willing to complete a screening questionnaire?", number: 2);
  /// Stores answer to question 2.
  bool answer2 = false;
  /// Stores display icon for question 2, depending on the current answer. (Depreciated)
  Icon icon2 = Icon(Icons.check_box_outline_blank);

  /// Displays question 3.
  QuestionCard question3 = QuestionCard(question: "Are you willing to have a blood test done, at no cost to you, as part of the screening process?", number: 3);
  /// Stores answer to question 3.
  bool answer3 = false;
  /// Stores display icon for question 3, depending on the current answer. (Depreciated)
  Icon icon3 = Icon(Icons.check_box_outline_blank);

  /// Displays question 4.
  QuestionCard question4 = QuestionCard(question: "Milk Matters has depots in various areas to make breast milk donation easier and more convenient for donor mothers. Are you able to collect sterile containers for freezing your milk donations in and / or drop off batches of frozen breast milk at a Milk Matters depot?", number: 4);
  /// Stores answer to question 4.
  bool answer4 = false;
  /// Stores display icon for question 4, depending on the current answer. (Depreciated)
  Icon icon4 = Icon(Icons.check_box_outline_blank);

  /// Displays question 5.
  QuestionCard question5 = QuestionCard(question: "Donor breast milk needs to be frozen within 24 hours of expressing and kept in the fridge until it is frozen.  Are you able to refrigerate and then freeze your breast milk at home?", number: 5);
  /// Stores answer to question 5.
  bool answer5 = false;
  /// Stores display icon for question 5, depending on the current answer. (Depreciated)
  Icon icon5 = Icon(Icons.check_box_outline_blank);

  /// Displays question 6.
  QuestionCard question6 = QuestionCard(question: "Are you aware that only breast milk that is in excess of your own baby’s needs should be donated?", number: 6);
  /// Stores answer to question 6.
  bool answer6 = false;
  /// Stores display icon for question 6, depending on the current answer. (Depreciated)
  Icon icon6 = Icon(Icons.check_box_outline_blank);

  /// Displays question 7.
  QuestionCard question7 = QuestionCard(question: "Do you understand that the breast milk you donate is pasteurised and microbiologically tested before being dispensed on a prescription basis to qualifying premature babies in state and private neonatal ICUs?", number: 7);
  /// Stores answer to question 7.
  bool answer7 = false;
  /// Stores display icon for question 7, depending on the current answer. (Depreciated)
  Icon icon7 = Icon(Icons.check_box_outline_blank);

  @override
  /// Builds the page, using the provided BuildContext.
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: Colors.blue[50],
            appBar: AppBar(
              title: Text(
                'Become A Donor',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.grey[700],
                ),
              ),
              centerTitle: true,
              elevation: 1.0,
              backgroundColor: Hexcolor('#fddcd8'),
              iconTheme: IconThemeData(
                color: Colors.grey[700],
              ),
            ),
            drawer: NavDrawer('BecomeADonor'),
            body: Container(
                child: ListView(
                  physics: BouncingScrollPhysics(),
                  children: <Widget>[
                    Container(
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          children: [
                            Text(
                              'Thank you for your interest in becoming a Milk Matters Donor!',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 18.0,
                                color: Colors.grey[700],
                                letterSpacing: 1.0,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              'The questions below aim to determine your eligibility as a donor and provide some insight into the Milk Matters donation process.\n\n'
                              'Once you complete the questions you can send a generated email containing your answers to Milk Matters by pressing the \'Send Application\' button.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 15.0,
                                color: Colors.grey[700],
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Card(
                      clipBehavior: Clip.antiAlias,
                      child: Column (
                        children: [
                          question1,
                          ListTile(
                            title: const Text("Yes"),
                            leading: Radio(
                              value: true,
                              groupValue: answer1,
                              onChanged: (bool choice) {
                                setState(() {
                                  answer1 = choice;
                                });
                              },
                            ),
                          ),
                          ListTile(
                            title: const Text("No"),
                            leading: Radio(
                              value: false,
                              groupValue: answer1,
                              onChanged: (bool choice) {
                                setState(() {
                                  answer1 = choice;
                                });
                              },
                            ),
                          ),
                          /**
                          ButtonBar(
                            alignment: MainAxisAlignment.end,
                            children: [
                              FlatButton.icon(
                                icon: icon1,
                                onPressed: () {
                                  if (!answer1) {
                                    setState(() {answer1 = true; icon1 = Icon(Icons.check_box);});
                                  }
                                  else {
                                    setState(() {answer1 = false; icon1 = Icon(Icons.check_box_outline_blank);});
                                  }
                                },
                                label: Text(answer1.toString().toUpperCase()),
                              ),
                            ],
                          ), */
                        ],
                      )
                    ),
                    Card(
                        clipBehavior: Clip.antiAlias,
                        child: Column (
                          children: [
                            question2,
                            ListTile(
                              title: const Text("Yes"),
                              leading: Radio(
                                value: true,
                                groupValue: answer2,
                                onChanged: (bool choice) {
                                  setState(() {
                                    answer2 = choice;
                                  });
                                },
                              ),
                            ),
                            ListTile(
                              title: const Text("No"),
                              leading: Radio(
                                value: false,
                                groupValue: answer2,
                                onChanged: (bool choice) {
                                  setState(() {
                                    answer2 = choice;
                                  });
                                },
                              ),
                            ),
                            /**
                            ButtonBar(
                              alignment: MainAxisAlignment.end,
                              children: [
                                FlatButton.icon(
                                  icon: icon2,
                                  onPressed: () {
                                    if (!answer2) {
                                      setState(() {answer2 = true; icon2 = Icon(Icons.check_box);});
                                    }
                                    else {
                                      setState(() {answer2 = false; icon2 = Icon(Icons.check_box_outline_blank);});
                                    }
                                  },
                                  label: Text(answer2.toString().toUpperCase()),
                                ),
                              ],
                            ),*/
                          ],
                        )
                    ),
                    Card(
                        clipBehavior: Clip.antiAlias,
                        child: Column (
                          children: [
                            question3,
                            ListTile(
                              title: const Text("Yes"),
                              leading: Radio(
                                value: true,
                                groupValue: answer3,
                                onChanged: (bool choice) {
                                  setState(() {
                                    answer3 = choice;
                                  });
                                },
                              ),
                            ),
                            ListTile(
                              title: const Text("No"),
                              leading: Radio(
                                value: false,
                                groupValue: answer3,
                                onChanged: (bool choice) {
                                  setState(() {
                                    answer3 = choice;
                                  });
                                },
                              ),
                            ),
                            /**
                            ButtonBar(
                              alignment: MainAxisAlignment.end,
                              children: [
                                FlatButton.icon(
                                  icon: icon3,
                                  onPressed: () {
                                    if (!answer3) {
                                      setState(() {answer3 = true; icon3 = Icon(Icons.check_box);});
                                    }
                                    else {
                                      setState(() {answer3 = false; icon3 = Icon(Icons.check_box_outline_blank);});
                                    }
                                  },
                                  label: Text(answer3.toString().toUpperCase()),
                                ),
                              ],
                            ),*/
                          ],
                        )
                    ),
                    Card(
                        clipBehavior: Clip.antiAlias,
                        child: Column (
                          children: [
                            question4,
                            ListTile(
                              title: const Text("Yes"),
                              leading: Radio(
                                value: true,
                                groupValue: answer4,
                                onChanged: (bool choice) {
                                  setState(() {
                                    answer4 = choice;
                                  });
                                },
                              ),
                            ),
                            ListTile(
                              title: const Text("No"),
                              leading: Radio(
                                value: false,
                                groupValue: answer4,
                                onChanged: (bool choice) {
                                  setState(() {
                                    answer4 = choice;
                                  });
                                },
                              ),
                            ),
                            /**
                            ButtonBar(
                              alignment: MainAxisAlignment.end,
                              children: [
                                FlatButton.icon(
                                  icon: icon4,
                                  onPressed: () {
                                    if (!answer4) {
                                      setState(() {answer4 = true; icon4 = Icon(Icons.check_box);});
                                    }
                                    else {
                                      setState(() {answer4 = false; icon4 = Icon(Icons.check_box_outline_blank);});
                                    }
                                  },
                                  label: Text(answer4.toString().toUpperCase()),
                                ),
                              ],
                            ),*/
                          ],
                        )
                    ),
                    Card(
                        clipBehavior: Clip.antiAlias,
                        child: Column (
                          children: [
                            question5,
                            ListTile(
                              title: const Text("Yes"),
                              leading: Radio(
                                value: true,
                                groupValue: answer5,
                                onChanged: (bool choice) {
                                  setState(() {
                                    answer5 = choice;
                                  });
                                },
                              ),
                            ),
                            ListTile(
                              title: const Text("No"),
                              leading: Radio(
                                value: false,
                                groupValue: answer5,
                                onChanged: (bool choice) {
                                  setState(() {
                                    answer5 = choice;
                                  });
                                },
                              ),
                            ),
                            /**
                            ButtonBar(
                              alignment: MainAxisAlignment.end,
                              children: [
                                FlatButton.icon(
                                  icon: icon5,
                                  onPressed: () {
                                    if (!answer5) {
                                      setState(() {answer5 = true; icon5 = Icon(Icons.check_box);});
                                    }
                                    else {
                                      setState(() {answer5 = false; icon5 = Icon(Icons.check_box_outline_blank);});
                                    }
                                  },
                                  label: Text(answer5.toString().toUpperCase()),
                                ),
                              ],
                            ),*/
                          ],
                        )
                    ),
                    Card(
                        clipBehavior: Clip.antiAlias,
                        child: Column (
                          children: [
                            question6,
                            ListTile(
                              title: const Text("Yes"),
                              leading: Radio(
                                value: true,
                                groupValue: answer6,
                                onChanged: (bool choice) {
                                  setState(() {
                                    answer6 = choice;
                                  });
                                },
                              ),
                            ),
                            ListTile(
                              title: const Text("No"),
                              leading: Radio(
                                value: false,
                                groupValue: answer6,
                                onChanged: (bool choice) {
                                  setState(() {
                                    answer6 = choice;
                                  });
                                },
                              ),
                            ),
                            /**
                            ButtonBar(
                              alignment: MainAxisAlignment.end,
                              children: [
                                FlatButton.icon(
                                  icon: icon6,
                                  onPressed: () {
                                    if (!answer6) {
                                      setState(() {answer6 = true; icon6 = Icon(Icons.check_box);});
                                    }
                                    else {
                                      setState(() {answer6 = false; icon6 = Icon(Icons.check_box_outline_blank);});
                                    }
                                  },
                                  label: Text(answer6.toString().toUpperCase()),
                                ),
                              ],
                            ),*/
                          ],
                        )
                    ),
                    Card(
                        clipBehavior: Clip.antiAlias,
                        child: Column (
                          children: [
                            question7,
                            ListTile(
                              title: const Text("Yes"),
                              leading: Radio(
                                value: true,
                                groupValue: answer7,
                                onChanged: (bool choice) {
                                  setState(() {
                                    answer7 = choice;
                                  });
                                },
                              ),
                            ),
                            ListTile(
                              title: const Text("No"),
                              leading: Radio(
                                value: false,
                                groupValue: answer7,
                                onChanged: (bool choice) {
                                  setState(() {
                                    answer7 = choice;
                                  });
                                },
                              ),
                            ),
                            /**
                            ButtonBar(
                              alignment: MainAxisAlignment.end,
                              children: [
                                FlatButton.icon(
                                  icon: icon7,
                                  onPressed: () {
                                    if (!answer7) {
                                      setState(() {answer7 = true; icon7 = Icon(Icons.check_box);});
                                    }
                                    else {
                                      setState(() {answer7 = false; icon7 = Icon(Icons.check_box_outline_blank);});
                                    }
                                  },
                                  label: Text(answer7.toString().toUpperCase()),
                                ),
                              ],
                            ),*/
                          ],
                        )
                    ),
                    Container (
                      margin: EdgeInsets.all(20),
                      child: FlatButton(
                        child: Text("Send Application", style: TextStyle(
                          color: Colors.grey[200],
                        )
                        ),
                        color: Hexcolor('#dc0963'),
                        onPressed: () async {
                          final Email email = Email(
                            //Need to check how to access answer boolean, currently returns null.
                            body: 'This is an automated email generated by the '
                                'Milk Matters mobile app. This potential donor '
                                'has filled in the questionnaire, and has agreed'
                                ' to send their responses to Milk Matters. '
                                'Below are their responses:'
                                '\n\n Question 1: '  +question1.question + '\nAnswer: ' + answer1.toString().toUpperCase() +
                                '\n\n Question 2: '  +question2.question + '\nAnswer: ' + answer2.toString().toUpperCase() +
                                '\n\n Question 3: '  +question3.question + '\nAnswer: ' + answer3.toString().toUpperCase() +
                                '\n\n Question 4: '  +question4.question + '\nAnswer: ' + answer4.toString().toUpperCase() +
                                '\n\n Question 5: '  +question5.question + '\nAnswer: ' + answer5.toString().toUpperCase() +
                                '\n\n Question 6: '  +question6.question + '\nAnswer: ' + answer6.toString().toUpperCase() +
                                '\n\n Question 7: '  +question7.question + '\nAnswer: ' + answer7.toString().toUpperCase(),
                            subject: 'Milk Matters App: Donor Application',
                            recipients: ['gerhardserton@gmail.com'],
                            isHTML: false,
                          );

                          await FlutterEmailSender.send(email);
                          Navigator.pushReplacementNamed(context, '/home');
                        },
                      ),
                    )

                  ],
                )
            )
        )
      );
  }
}