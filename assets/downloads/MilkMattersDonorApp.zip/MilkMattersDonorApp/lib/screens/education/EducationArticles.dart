import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:milk_matters_donor_app/customWidgets/cards/ArticleCard.dart';
import 'package:milk_matters_donor_app/customWidgets/NavDrawer.dart';
import 'package:milk_matters_donor_app/models/EducationArticle.dart';

/// The stateless widget which displays the eduction articles screen
class EducationArticles extends StatelessWidget {

  /// setup variables to store argument data
  Map arguementData = {};
  List<EducationArticle> articles;

  @override
  Widget build(BuildContext context) {

    /// retrieve argument data
    arguementData = arguementData.isNotEmpty ? arguementData : ModalRoute.of(context).settings.arguments;
    articles = arguementData['articles'];

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.blue[50],
        appBar: AppBar(
          title: Text(
            arguementData['category'],
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey[700],
            ),
          ),
          centerTitle: true,
          elevation: 1.0,
          backgroundColor: Hexcolor('#fddcd8'),
          iconTheme: IconThemeData(
            color: Colors.grey[700],
          ),
        ),
        drawer: NavDrawer('Education Articles'),
        body: Container(
          child: ListView.builder(
            physics: BouncingScrollPhysics(),
            // Let the ListView know how many items it needs to build.
            itemCount: articles.length,
            // Provide a builder function.
            itemBuilder: (context, index) {
              final item = articles[index];
              return ArticleCard(
                eduArticle: item,
              );
            },
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          label: Text(
            'Suggest An Article',
            style: TextStyle(
              color: Colors.grey[200],
              fontSize: 15.0,
            ),
          ),
          backgroundColor: Hexcolor('#dc0963'),
          onPressed: (){
            Navigator.pushNamed(context, '/suggestAnArticle');
          },
        ),
      ),
    );
  }
}