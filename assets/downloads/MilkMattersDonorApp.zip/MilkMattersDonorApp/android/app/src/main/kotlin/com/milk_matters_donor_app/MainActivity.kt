package com.milk_matters_donor_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
